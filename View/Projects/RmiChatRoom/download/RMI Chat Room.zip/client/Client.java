/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import core.User;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.Scanner;

import remote.ClientRmi;
import remote.ClientRmiImp;
import remote.Message;
import remote.UserRmi;

/**
 * @author D00156839
 */
public class Client
{

    public static void main(String args[])
    {
        try
        {
            int portNum = 1111;
            Scanner kb = new Scanner(System.in);
            String registryURL = "rmi://localhost:" + portNum + "/users";
            UserRmi rmi = (UserRmi) Naming.lookup(registryURL);

////           User u = new User("mick",
////                    "fallout", "monaghan", "123456");


            //DO THEY HAVE AN ACCOUNT
            System.out.println("Do you have an account? true,false ");
            boolean hasAcc = kb.nextBoolean();

            if (hasAcc)
            {
                //GET THEIR USERNAME AND PASSWORD
                kb.nextLine();
                System.out.println("Username: ");
                String username = kb.nextLine();
                System.out.println("Password: ");
                String password = kb.nextLine();

                boolean loggedIn = logIn(rmi, username, password);

                if (loggedIn)
                {
                    System.out.println("Logging in......Logged in");
                    int logOut = 0;
                    while (logOut != 1)
                    {
                        ClientRmi callbackObj = new ClientRmiImp();
                        System.out.println("Press 1 to log out");
                        System.out.println("Press 2 to add chat room");
                        System.out.println("Press 3 to view rooms");
                        System.out.println("Press 4 to join room");
                        System.out.println("Press 5 to send private Message");
                        System.out.println("Press 6 to view private Message");
                        logOut = kb.nextInt();

                        if (logOut == 2)
                        {
                            kb.nextLine();
                            System.out.println("Enter chat name: ");
                            String chatName = kb.nextLine();
//                             rmi.addChatRoom(chatName);
                        }
                        else if (logOut == 3)
                        {
                            System.out.println(rmi.getChats());
                        }
                        else if (logOut == 4)
                        {
                            kb.nextLine();
                            System.out.println("Enter chat to join: ");
                            String chatName = kb.nextLine();
                            boolean inChat = rmi.addUser(chatName, username, "psword", callbackObj);
                            while (inChat)
                            {

                                System.out.println("Enter message: ");
                                String message = kb.nextLine();
                                rmi.sendMessage(chatName, username, message);

                            }
                        }
                        else if (logOut == 5)
                        {
                            rmi.sendPrivateMessage(username, "ryan", "hi this is a private message to ryan");

                        }
                        else if (logOut == 6)
                        {
                            Message m = rmi.viewPrivateMessages(username);
                            System.out.println(m.getMessage());
                        }
                    }

                    if (logOut == 1)
                    {
                        System.out.println("Logging out......Logged in");
                    }
                }
                else
                {
                    System.out.println("No account or already logged in");
                }
            }


        } catch (Exception e)
        {
            System.out.println("Exception in SomeClient: " + e);
        }

    }

    public static boolean logIn(UserRmi rmi, String username, String password) throws RemoteException, SQLException
    {


        boolean loggedIn = rmi.logIn(username, password);

        if (loggedIn)
        {
            return true;

        }

        return false;

    }

}
