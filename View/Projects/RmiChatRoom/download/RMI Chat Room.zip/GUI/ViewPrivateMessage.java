package GUI;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import remote.Message;
import remote.UserRmi;

import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 * Created by Tom Mennis/D00156078 on 16/12/2015.
 */
public class ViewPrivateMessage
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;
    private static String username;

    public static void display(UserRmi passedRmi, String passedUserName) throws Exception
    {
        rmi = passedRmi;
        username = passedUserName;
        window = new Stage();

        Label displayMessage;
        try
        {
            Message receivedMessage = rmi.viewPrivateMessages(username);
            displayMessage = new Label("From :\t" + receivedMessage.getSender() + "\nMessage :\t" + receivedMessage.getMessage());
        }
        catch(Exception e)
        {
            displayMessage = new Label("You have no private Messages");
        }

        GridPane.setConstraints(displayMessage,0,0);

        Button goBackToLogin = new Button("Back To Main Menu");
        GridPane.setConstraints(goBackToLogin, 0,1);

        goBackToLogin.setOnAction(e -> {
            window.close();
            try
            {
                LoggedIn.display(rmi,username);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.autosize();

        grid.getChildren().addAll(displayMessage,goBackToLogin);

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();

    }
}
