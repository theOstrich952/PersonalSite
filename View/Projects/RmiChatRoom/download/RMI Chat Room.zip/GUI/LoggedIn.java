package GUI;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import remote.ClientRmi;
import remote.ClientRmiImp;
import remote.UserRmi;

import java.rmi.RemoteException;

/**
 * Created by Tom Mennis/D00156078 on 12/12/2015.
 */
public class LoggedIn
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;
    private static ClientRmi callbackObj;

    public static void display(UserRmi passedRmi, String userName) throws Exception
    {
        rmi = passedRmi;
        callbackObj  =  new ClientRmiImp();
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Main Menu");


        Button addChatRoom = new Button("Add Chat Room");
        GridPane.setConstraints(addChatRoom, 0, 1);

        Button viewChatRooms = new Button("View Chat Room");
        GridPane.setConstraints(viewChatRooms, 0, 2);

        Button joinChatRoom = new Button("Join Chat Room");
        GridPane.setConstraints(joinChatRoom, 0, 3);

        Button sendPrivateMessage = new Button("Send Private Message");
        GridPane.setConstraints(sendPrivateMessage, 0, 4);

        Button viewPrivateMessages = new Button("View Private Messages");
        GridPane.setConstraints(viewPrivateMessages, 0, 5);

        Button logOut = new Button("Log Out");
        GridPane.setConstraints(logOut, 0, 6);


        addChatRoom.setOnAction(e -> {
            window.close();
            AddChatRoom.display(rmi,userName);
        });


        viewChatRooms.setOnAction(e -> {
            window.close();
            try
            {
                ViewChatRoom.display(rmi, userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });


        joinChatRoom.setOnAction(e -> {
            window.close();
            try
            {
                JoinChatRoom.display(rmi,callbackObj, userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });


        sendPrivateMessage.setOnAction(e -> {
            window.close();
            try
            {
                SendPrivateMessage.display(rmi,userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });

        viewPrivateMessages.setOnAction(e -> {
            window.close();
            try
            {
                ViewPrivateMessage.display(rmi, userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });


        logOut.setOnAction(e -> {
            window.close();
            try
            {
                rmi.logOut(userName);
            } catch (RemoteException e1)
            {
                e1.printStackTrace();
            }
            Login.display(rmi);
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.autosize();

        grid.getChildren().addAll(addChatRoom, viewChatRooms, joinChatRoom, sendPrivateMessage, viewPrivateMessages, logOut);

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }
}
