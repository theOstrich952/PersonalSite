package GUI;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import remote.UserRmi;

/**
 * Created by User on 12/12/2015.
 */
public class Login
{
    private static Stage window;
    private static UserRmi rmi;
    private static Scene scene;

    public static void display(UserRmi passedRmi)
    {
        rmi = passedRmi;
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Main Menu");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        Label userName = new Label("Username : ");
        GridPane.setConstraints(userName, 0, 0);

        TextField nameInput = new TextField();
        nameInput.setPromptText("Username");
        GridPane.setConstraints(nameInput, 1, 0);

        Label loginError = new Label();
        GridPane.setConstraints(loginError, 1, 1);

        Label password = new Label("Password : ");
        GridPane.setConstraints(password, 0, 2);

        TextField passwordInput = new TextField();
        passwordInput.setPromptText("Password");
        GridPane.setConstraints(passwordInput, 1, 2);

        Button createAccount = new Button("Create Account");
        GridPane.setConstraints(createAccount, 0, 3);

        Button loginButton = new Button("Login");
        GridPane.setConstraints(loginButton, 1, 3);


        nameInput.setOnMouseClicked(e -> {
            if (!loginError.getText().isEmpty())
            {
                loginError.setText("");
                nameInput.clear();
                window.sizeToScene();
            }
        });
        passwordInput.setOnMouseClicked(e -> {
            if (!loginError.getText().isEmpty())
            {
                loginError.setText("");
                passwordInput.clear();
                window.sizeToScene();
            }
        });


        createAccount.setOnAction(e -> {
            window.close();
            try
            {
                CreateUser.display(rmi);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });


        loginButton.setOnAction(e -> {
            try
            {
                boolean account = processLogin(nameInput.getText(), passwordInput.getText());
                if (account)
                {
                    window.close();
                    LoggedIn.display(rmi, nameInput.getText());
                }
                else
                {
                    loginError.setText("Error\nUser Name or password may be Incorrect or\nYou could already be logged in!!!");
                    window.sizeToScene();
                }
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });

        grid.getChildren().addAll(userName, loginError, nameInput, password, passwordInput, createAccount, loginButton);
        grid.autosize();
        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }

    /**
     * Check if logged in or have account
     **/
    private static boolean processLogin(String userName, String password) throws Exception
    {
        return rmi.logIn(userName, password);
    }
}
