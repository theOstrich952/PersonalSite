package GUI;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import remote.ClientRmi;
import remote.UserRmi;

/**
 * Created by Tom Mennis/D00156078 on 13/12/2015.
 */
public class JoinChatRoom
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;
    private static String userName;
    private static ClientRmi callbackObj;

    public static void display(UserRmi passedRmi, ClientRmi passedCallbackObj, String passedUserName) throws Exception
    {
        rmi = passedRmi;
        userName = passedUserName;
        callbackObj =  passedCallbackObj;

        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Joining Chat Room");


        Label chatRoomName = new Label("Chat Room Name : ");
        GridPane.setConstraints(chatRoomName, 0, 0);

        TextField chatRoomNameInput = new TextField();
        chatRoomNameInput.setPromptText("Enter Name");
        GridPane.setConstraints(chatRoomNameInput, 1, 0);

        Label chatRoomPassword = new Label("Chat Room Password : ");
        GridPane.setConstraints(chatRoomPassword, 0, 1);

        TextField chatRoomPasswordInput = new TextField();
        chatRoomPasswordInput.setPromptText("Enter Password");
        GridPane.setConstraints(chatRoomPasswordInput, 1, 1);

        Button joinChatRoom = new Button("Join Chat Room");
        joinChatRoom.setOnAction(e -> {
            try
            {
                boolean inChat = processJoinChat(chatRoomNameInput.getText().trim(),chatRoomPasswordInput.getText().trim());
                System.out.println(inChat);
                if (inChat)
                {
                    window.close();
                    Chat.display(rmi, userName, chatRoomNameInput.getText());
                }
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });
        GridPane.setConstraints(joinChatRoom, 0, 2);

        Button goBackToLogin = new Button("Back To Main Menu");
        goBackToLogin.setOnAction(e -> {
            window.close();
            try
            {
                LoggedIn.display(rmi, userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });
        GridPane.setConstraints(goBackToLogin, 1, 2);


        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.getChildren().addAll(chatRoomName, chatRoomNameInput, chatRoomPassword, chatRoomPasswordInput, joinChatRoom, goBackToLogin);
        grid.autosize();

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }

    private static boolean processJoinChat(String chatRoomName,String chatUserPassword) throws Exception
    {
        return rmi.addUser(chatRoomName, userName, chatUserPassword, callbackObj);
    }
}
