package GUI;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import remote.UserRmi;

import java.rmi.RemoteException;

/**
 * Created by Tom Mennis/D00156078 on 16/12/2015.
 */
public class SendPrivateMessage
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;

    public static void display(UserRmi passedRmi, String userName) throws Exception
    {
        rmi = passedRmi;
        window = new Stage();

        Label recipient = new Label("Recipient :");
        GridPane.setConstraints(recipient, 0, 0);

        TextField recipientName = new TextField();
        recipientName.setPromptText("Recipient");
        GridPane.setConstraints(recipientName, 1, 0);

        Button sendMessage = new Button("Send Message");
        GridPane.setConstraints(sendMessage, 0, 2);

        TextArea message = new TextArea();
        message.setPromptText("Message ");
        GridPane.setConstraints(message, 1, 2);

        Button goBackToLogin = new Button("Back To Main Menu");
        GridPane.setConstraints(goBackToLogin, 1, 3);


        sendMessage.setOnAction(e -> {
            try
            {
                rmi.sendPrivateMessage(userName, recipientName.getText().trim(), message.getText().trim());
            } catch (RemoteException e1)
            {
                e1.printStackTrace();
            }
        });


        goBackToLogin.setOnAction(e -> {
            window.close();
            try
            {
                LoggedIn.display(rmi,userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });


        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.getChildren().addAll(recipient, recipientName, message, sendMessage, goBackToLogin);
        grid.autosize();

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }
}
