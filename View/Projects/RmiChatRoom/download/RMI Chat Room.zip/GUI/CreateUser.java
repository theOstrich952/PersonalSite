package GUI;

import core.User;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import remote.UserRmi;

import java.rmi.RemoteException;

/**
 * Created by Tom Mennis/D00156078 on 15/12/2015.
 */
public class CreateUser
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;

    public static void display(UserRmi passedRmi) throws Exception
    {
        rmi = passedRmi;
        window = new Stage();

        Label userName = new Label("Username : ");
        GridPane.setConstraints(userName, 0, 0);

        TextField nameInput = new TextField();
        nameInput.setPromptText("Username");
        GridPane.setConstraints(nameInput, 1, 0);

        Label createError = new Label();
        GridPane.setConstraints(createError, 1, 1);

        Label password = new Label("Password : ");
        GridPane.setConstraints(password, 0, 2);

        TextField passwordInput = new TextField();
        passwordInput.setPromptText("Password");
        GridPane.setConstraints(passwordInput, 1, 2);

        Button createAccount = new Button("Create Account");
        GridPane.setConstraints(createAccount, 0, 3);

        Button goBackToLogin = new Button("Back To Main Menu");
        GridPane.setConstraints(goBackToLogin, 1, 3);


        createAccount.setOnAction(e -> {
            String username = nameInput.getText();
            String userpassword = passwordInput.getText();

            try
            {
                if (!userName.equals("") && !userpassword.equals(""))
                {
                    rmi.createUser(new User(username, userpassword));
                }
                else
                {
                    createError.setText("Error\nUser Name and password are Empty");
                    window.sizeToScene();
                }
            } catch (RemoteException e1)
            {
                e1.printStackTrace();
            }

        });

        nameInput.setOnMouseClicked(e -> {
            if (!createError.getText().isEmpty())
            {
                createError.setText("");
            }
        });

        goBackToLogin.setOnAction(e -> {
            window.close();
            try
            {
                Login.display(rmi);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.getChildren().addAll(userName, createError, nameInput, password, passwordInput, createAccount, goBackToLogin);
        grid.autosize();

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }
}
