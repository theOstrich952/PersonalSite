package GUI;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import remote.UserRmi;

/**
 * Created by Tom Mennis/D00156078 on 12/12/2015.
 */
public class AddChatRoom
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;
    private static String userName;

    public static void display(UserRmi passedRmi, String passedUserName)
    {
        rmi = passedRmi;
        userName = passedUserName;
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Adding Chat Room");

        Label chatRoomName = new Label("Chat Room Name : ");
        GridPane.setConstraints(chatRoomName, 0, 0);

        TextField chatRoomNameInput = new TextField();
        chatRoomNameInput.setPromptText("Name");
        GridPane.setConstraints(chatRoomNameInput, 1, 0);

        Label chatRoomPassword = new Label("Chat Room Password : ");
        GridPane.setConstraints(chatRoomPassword, 0, 1);

        TextField chatRoomPasswordInput = new TextField();
        chatRoomPasswordInput.setPromptText("Password");
        GridPane.setConstraints(chatRoomPasswordInput, 1, 1);

        Button createChatRoom = new Button("Create Chat Room");
        GridPane.setConstraints(createChatRoom, 0, 2);
        createChatRoom.setOnAction(e -> {
            boolean added = false;
            try
            {
                added = processAddChatRoom(chatRoomNameInput.getText(), chatRoomPasswordInput.getText());
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
            if (added)
            {
                window.close();
                alert("Chat Room Added");
            }
            else
            {
                window.close();
                alert("Chat Room NOT Added");
            }
        });

        Button backToLogin = new Button("Back to Main Menu");
        GridPane.setConstraints(backToLogin, 1, 2);
        backToLogin.setOnAction(e -> {
            window.close();
            try
            {
                LoggedIn.display(rmi, userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.autosize();

        grid.getChildren().addAll(chatRoomName, chatRoomNameInput, chatRoomPassword, chatRoomPasswordInput, createChatRoom, backToLogin);

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }

    public static void alert(String alert)
    {
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Chat Room Alert");

        Label added = new Label(alert);
        GridPane.setConstraints(added, 0, 0);

        Button okButton = new Button("Ok");
        okButton.setOnAction(e -> {
            window.close();
            display(rmi, userName);
        });
        GridPane.setConstraints(okButton, 1, 0);

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.autosize();

        grid.getChildren().addAll(added, okButton);

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();

    }

    private static boolean processAddChatRoom(String chatRoomName, String chatRoomPassword) throws Exception
    {
        return rmi.addChatRoom(chatRoomName,chatRoomPassword);
    }
}
