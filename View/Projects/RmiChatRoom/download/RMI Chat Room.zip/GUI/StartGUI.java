package GUI;
/**
 * Created by Tom Mennis, Michael Geehan and Ryan Finnigen on 10/12/2015.
 */

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import remote.UserRmi;
import java.rmi.Naming;

public class StartGUI extends Application
{
    //Global Variables
    private Stage window;
    private UserRmi rmi;

    public static void main(String[] args)
    {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception
    {
        int port = 1111;
        rmi = (UserRmi) Naming.lookup("rmi://localhost:" + port + "/users");
        window = primaryStage;
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        Button startChat = new Button("Start Chat");
        GridPane.setConstraints(startChat, 0, 2);
        startChat.setOnAction(e -> {
            window.close();
            Login.display(rmi);
        });

        grid.getChildren().add(startChat);
        grid.autosize();
        window.setScene(new Scene(grid));
        window.show();
    }
}
