package GUI;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import remote.UserRmi;

import java.rmi.RemoteException;

/**
 * Created by Tom Mennis/D00156078 on 13/12/2015.
 */
public class Chat
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;
    private static String username;
    public static Label chatText ;
    public static void display(UserRmi passedRmi, String passedUserName, String chatRoomName)
    {
        rmi = passedRmi;
        username = passedUserName;
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Chat Room " + chatRoomName);
        chatText = new Label();

        Button goBackToLogin = new Button("Back To Main Menu");
        goBackToLogin.setOnAction(e -> {
            window.close();
            try
            {
                LoggedIn.display(rmi, username);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });
        GridPane.setConstraints(goBackToLogin,0,0);


        ScrollPane scroll = new ScrollPane();
        scroll.setContent(chatText);
        scroll.setMinHeight(300);
        scroll.setMaxHeight(400);
        scroll.setMinWidth(350);

        GridPane.setConstraints(scroll,0,1);

        TextArea message = new TextArea();
        message.setPromptText("Enter Message");
        message.setMaxHeight(75);
        GridPane.setConstraints(message,0,2);
        message.setMaxHeight(100);

        Button sendMessage = new Button("Send");
        sendMessage.setOnAction(e -> {
            try
            {
                rmi.sendMessage(chatRoomName,username, message.getText());
                scroll.setVvalue(1.0);
                message.clear();
            } catch (RemoteException e1)
            {
                e1.printStackTrace();
            }
        });
        GridPane.setConstraints(sendMessage,0,3);

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        grid.getChildren().addAll(goBackToLogin,scroll,message,sendMessage);

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();

    }
}
