package GUI;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import remote.UserRmi;

import java.util.ArrayList;

/**
 * Created by Tom Mennis/D00156078 on 13/12/2015.
 */
public class ViewChatRoom
{
    private static Stage window;
    private static Scene scene;
    private static UserRmi rmi;
    private static String userName;

    public static void display(UserRmi passedRmi, String passedUserName) throws Exception
    {
        rmi = passedRmi;
        userName = passedUserName;
        window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Adding Chat Room");

        ArrayList<String> chatRooms = rmi.getChatRooms();
        ObservableList<String> data = FXCollections.observableArrayList(chatRooms);

        if(chatRooms.isEmpty())
        {
            data.add("There Are No Chat Rooms");
        }

        ListView<String> listView = new ListView<>(data);
        listView.setEditable(true);

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.autosize();
        StackPane pane = new StackPane();

        pane.getChildren().add(listView);
        pane.autosize();
        GridPane.setConstraints(pane, 0, 0);

        Button goBackToLogin = new Button("Back To Main Menu");
        goBackToLogin.setOnAction(e ->{
            window.close();
            try
            {
                LoggedIn.display(rmi, userName);
            } catch (Exception e1)
            {
                e1.printStackTrace();
            }
        });
        GridPane.setConstraints(goBackToLogin, 0, 1);

        grid.getChildren().addAll(pane, goBackToLogin);
        grid.autosize();

        scene = new Scene(grid);
        window.setScene(scene);
        window.show();
    }
}
