/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import remote.UserRmiStore;

/**
 * @author D00156839
 */
public class Server
{

    public static void main(String args[])
    {
        int portNum = 1111;
        String registryUrl;

        try
        {

            UserRmiStore exportedObj = new UserRmiStore();
            startRegistry(portNum);
            registryUrl = "rmi://localhost:" + portNum + "/users";
            Naming.rebind(registryUrl, exportedObj);
            System.out.println("Server Ready");

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static void startRegistry(int RMIPortNum) throws RemoteException
    {
        try
        {
            Registry registry = LocateRegistry.getRegistry(RMIPortNum);

            registry.list();
        } catch (RemoteException ex)
        {

            System.out.println("RMI registry cannot be located at port " + RMIPortNum);
            // Make a registry on that port.
            Registry registry = LocateRegistry.createRegistry(RMIPortNum);
            System.out.println("RMI registry created at port " + RMIPortNum);
        }

    }

}
