package remote;

import java.io.Serializable;

/**
 * @author D00156839
 */
public class Message implements Serializable
{

    private String recipient, sender, message;
    //add in date too
    //private Date date;

    public Message(String recipient, String sender, String message)
    {
        this.recipient = recipient;
        this.sender = sender;
        this.message = message;
    }

    public String getRecipient()
    {
        return recipient;
    }

    public String getSender()
    {
        return sender;
    }

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }
}
