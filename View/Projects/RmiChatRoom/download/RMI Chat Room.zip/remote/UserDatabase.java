package remote;

import java.sql.*;

public class UserDatabase
{
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/users";
    static final String USER = "root";
    static final String PASS = "";

    private Connection conn;
    private Statement stmt;

    public UserDatabase() throws ClassNotFoundException, SQLException
    {
        Class.forName(JDBC_DRIVER);
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
    }

    public boolean addUser(String username, String password) throws SQLException
    {
        //check if user exists
        stmt = conn.createStatement();
        String sql = "INSERT INTO users VALUES ('" + username + "', '" + password + "')";
        stmt.executeUpdate(sql);
        return true;
    }

    public boolean logIn(String username, String password) throws SQLException
    {
        stmt = conn.createStatement();
        String sql = "SELECT password from users where username = '" + username + "';";

        boolean logged = false;

        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next())
        {
            String userPassword = rs.getString("password");
            if (userPassword.equals(password))
            {
                logged = true;
            }
            else
            {
                logged = false;
            }
        }

        return logged;

    }
}