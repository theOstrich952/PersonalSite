/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package remote;

import core.User;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Michael
 */
public class ChatRooms {
    
    private HashMap<String,ChatRoom> chatRooms;
    private HashMap<ChatRoom, ArrayList<Message>> chatMessages;

    public ChatRooms()
    {
        chatRooms = new HashMap<>();
    }
    
    public void addChat(String chatName,String password)
    {
        //check chat doesnt exist
        ArrayList users = new ArrayList();
        ChatRoom c = new ChatRoom(chatName,password);
        chatRooms.put(chatName,c);
       
    }
    
     public ArrayList<ClientRmi> getUsers(String chatRoom)
    {
        if(chatRooms.containsKey(chatRoom))
        {
            ArrayList user = chatRooms.get(chatRoom).getUsers();
            return user;
        }
        return null;
    }
    
    public boolean addUser(String chatRoom,String password,ClientRmi callbackClientObject)
    {
        
        //check user isnt already in the chat and that chat exists
        if(chatRooms.containsKey(chatRoom))
        {
//            chatRooms.get(chatRoom).add(callbackClientObject);
            if(chatRooms.get(chatRoom).getPassword().equals(password))
            {
                chatRooms.get(chatRoom).addUser(callbackClientObject);
                return true;
            }
            
            return false;
        }
        return false;
    }

    public ArrayList<String> getChatRooms()
    {
        ArrayList<String> tempChatRooms = new ArrayList<>(chatRooms.keySet());
        return tempChatRooms;
    }
    @Override
    public String toString() {
        return "ChatRooms{" + "chatRooms=" + chatRooms.keySet() + '}';
    }
    
   
    
    
    
}
