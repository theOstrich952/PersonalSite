/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package remote;

import core.User;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Michael
 */
public class UserRmiStore extends UnicastRemoteObject implements UserRmi
{
    HashMap<String, User> userStore = new HashMap<>();
    HashMap<String, User> loggedInUsers = new HashMap<>();
    HashMap<String, String> chatMessages = new HashMap<>();
    ChatRooms chats = new ChatRooms();
    UserDatabase db;
    MessageStore messageStore;

    public UserRmiStore() throws RemoteException, ClassNotFoundException, SQLException
    {
        super();
        db = new UserDatabase();
        messageStore = new MessageStore();
    }

    @Override
    public boolean createUser(User u) throws RemoteException
    {

        boolean created = false;
        try
        {
            created = db.addUser(u.getUsername(), u.getPassword());
        } catch (SQLException ex)
        {
            Logger.getLogger(UserRmiStore.class.getName()).log(Level.SEVERE, null, ex);
        }


        return created;
    }

    @Override
    public boolean logIn(String username, String password) throws RemoteException, SQLException
    {
        boolean loggedIn = db.logIn(username, password);
        if (loggedIn)
        {
            if (loggedInUsers.containsKey(username))
            {
                return false;
            }
            else
            {
                loggedInUsers.put(username, new User(username, password));
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    @Override
    public boolean logOut(String username) throws RemoteException
    {
        loggedInUsers.remove(username);


        return true;
    }

    public boolean addChatRoom(String name, String password)
    {
        chats.addChat(name, password);
        return true;
    }

    public String getChats()
    {
        return chats.toString();
    }

    public ArrayList<String> getChatRooms()
    {
        return chats.getChatRooms();
    }

    public boolean addUser(String chatRoom, String username, String password, ClientRmi callbackClientObject)
    {
        boolean added = false;

        if (loggedInUsers.containsKey(username))
        {

            User u = userStore.get(username);
            added = chats.addUser(chatRoom, password, callbackClientObject);
//             users.add(callbackClientObject);
        }

        return added;
    }

    public String sendMessage(String chatName, String username, String message) throws RemoteException
    {
        ArrayList<ClientRmi> users = chats.getUsers(chatName);
        for (ClientRmi c : users)
        {
            c.notifyMe("From " + username + ": " + message);
        }
        return "";
    }

    public boolean sendPrivateMessage(String sender, String recipient, String message)
    {
        Message m = new Message(recipient, sender, message);
        //get boolean back here
        messageStore.sendPrivateMessage(m);
        return true;
    }

    public Message viewPrivateMessages(String userName)
    {
        Message m = messageStore.viewPrivateMessage(userName);
        return m;
    }
}
