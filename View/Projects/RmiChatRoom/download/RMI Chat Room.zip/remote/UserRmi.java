/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remote;

import core.User;
import java.rmi.Remote;
import java.sql.SQLException;
import java.util.ArrayList;


/**
 *
 * @author D00156839
 */
public interface UserRmi extends Remote
{
   public boolean createUser(User u) throws java.rmi.RemoteException;
   public boolean logIn(String username, String password) throws java.rmi.RemoteException, SQLException;
   public boolean logOut(String username) throws java.rmi.RemoteException;
   public boolean addChatRoom(String name,String password) throws java.rmi.RemoteException;
   public boolean addUser(String chatRoom,String username,String password,ClientRmi callbackClientObject) throws java.rmi.RemoteException;
   public String getChats() throws java.rmi.RemoteException;
   public ArrayList<String> getChatRooms() throws java.rmi.RemoteException;
   public String sendMessage(String chatName,String username,String message) throws java.rmi.RemoteException;
   public boolean sendPrivateMessage(String sender,String recipient,String message) throws java.rmi.RemoteException;
   public Message viewPrivateMessages(String userName) throws java.rmi.RemoteException;
}
