/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remote;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author D00156839
 */
public class MessageStore
{
    private ArrayList<Message> privateMessages;

    public MessageStore()
    {
        this.privateMessages = new ArrayList<>();
    }

    public boolean sendPrivateMessage(Message m)
    {
        this.privateMessages.add(m);
        return false;
    }

    public Message viewPrivateMessage(String user)
    {
        for (int i = 0; i < this.privateMessages.size(); i++)
        {
            if (this.privateMessages.get(i).getRecipient().equals(user))
            {
                return this.privateMessages.get(i);
            }
        }
        return null;
    }
}
