/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package remote;

import GUI.Chat;
import javafx.application.Platform;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * @author Michael
 */
public class ClientRmiImp extends UnicastRemoteObject implements ClientRmi
{

    public ClientRmiImp() throws RemoteException
    {

        super();
    }

    @Override
    public String notifyMe(String message) throws RemoteException
    {
        System.out.println(message);


        Platform.runLater(() -> {
            try
            {
                Chat.chatText.setText(Chat.chatText.getText() + "\n" + message);
            }
            finally
            {
            }
        });

        return message;
    }
}
