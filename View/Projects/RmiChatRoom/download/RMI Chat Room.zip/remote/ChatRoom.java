/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package remote;

/**
 * @author Ryan
 */

import java.io.Serializable;
import java.util.ArrayList;

public class ChatRoom implements Serializable
{
    private String name, password;
    private ArrayList<ClientRmi> users;

    public ChatRoom(String name, String password)
    {
        this.name = name;
        this.password = password;
        this.users = new ArrayList<>();


    }

    public String getName()
    {
        return name;
    }

    public String getPassword()
    {
        return password;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public void addUser(ClientRmi callbackClientObject)
    {
        users.add(callbackClientObject);
    }

    public ArrayList<ClientRmi> getUsers()
    {
        return users;
    }


}
